﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsFormsApplication1
{
    public class posicion
    {

        int casilla=1;
        int[,] matrix_pos = new int[63, 2];
        public posicion()
        {
            matrix_pos[0, 0] = 137;
            matrix_pos[0, 1] = 357;

            matrix_pos[1, 0] = 179;
            matrix_pos[1, 1] = 357;

            matrix_pos[2, 0] = 220;
            matrix_pos[2, 1] = 357;

            matrix_pos[3, 0] = 258;
            matrix_pos[3, 1] = 357;

            matrix_pos[4, 0] = 305;
            matrix_pos[4, 1] = 357;

            matrix_pos[5, 0] = 345;
            matrix_pos[5, 1] = 357;

            matrix_pos[6, 0] = 380;
            matrix_pos[6, 1] = 357;

            matrix_pos[7, 0] = 418;
            matrix_pos[7, 1] = 357;

            matrix_pos[8, 0] = 454;
            matrix_pos[8, 1] = 337;

            matrix_pos[9, 0] = 454;
            matrix_pos[9, 1] = 303;

            matrix_pos[10, 0] = 454;
            matrix_pos[10, 1] = 271;

            matrix_pos[11, 0] = 454;
            matrix_pos[11, 1] = 238;

            matrix_pos[12, 0] = 454;
            matrix_pos[12, 1] = 205;

            matrix_pos[13, 0] = 454;
            matrix_pos[13, 1] = 171;

            matrix_pos[14, 0] = 454;
            matrix_pos[14, 1] = 135;

            matrix_pos[15, 0] = 454;
            matrix_pos[15, 1] = 103;

            matrix_pos[16, 0] = 454;
            matrix_pos[16, 1] = 75;

            matrix_pos[17, 0] = 454;
            matrix_pos[17, 1] = 36;

            matrix_pos[18, 0] = 419;
            matrix_pos[18, 1] = 16;

            matrix_pos[19, 0] = 382;
            matrix_pos[19, 1] = 17;

            matrix_pos[20, 0] = 340;
            matrix_pos[20, 1] = 17;

            matrix_pos[21, 0] = 300;
            matrix_pos[21, 1] = 17;

            matrix_pos[22, 0] = 261;
            matrix_pos[22, 1] = 17;

            matrix_pos[23, 0] = 221;
            matrix_pos[23, 1] = 17;

            matrix_pos[24, 0] = 176;
            matrix_pos[24, 1] = 17;

            matrix_pos[25, 0] = 138;
            matrix_pos[25, 1] = 17;

            matrix_pos[26, 0] = 95;
            matrix_pos[26, 1] = 17;

            matrix_pos[27, 0] = 57;
            matrix_pos[27, 1] = 17;

            matrix_pos[28, 0] = 24;
            matrix_pos[28, 1] = 37;

            matrix_pos[29, 0] = 24;
            matrix_pos[29, 1] = 75;

            matrix_pos[30, 0] = 24;
            matrix_pos[30, 1] = 104;

            matrix_pos[31, 0] = 24;
            matrix_pos[31, 1] = 134;

            matrix_pos[32, 0] = 24;
            matrix_pos[32, 1] = 173;

            matrix_pos[33, 0] = 24;
            matrix_pos[33, 1] = 206;

            matrix_pos[34, 0] = 24;
            matrix_pos[34, 1] = 236;

            matrix_pos[35, 0] = 24;
            matrix_pos[35, 1] = 271;

            matrix_pos[36, 0] = 59;
            matrix_pos[36, 1] = 292;

            matrix_pos[37, 0] = 99;
            matrix_pos[37, 1] = 288;

            matrix_pos[38, 0] = 136;
            matrix_pos[38, 1] = 288;

            matrix_pos[39, 0] = 178;
            matrix_pos[39, 1] = 288;

            matrix_pos[40, 0] = 217;
            matrix_pos[40, 1] = 288;

            matrix_pos[41, 0] = 261;
            matrix_pos[41, 1] = 288;

            matrix_pos[42, 0] = 298;
            matrix_pos[42, 1] = 288;

            matrix_pos[43, 0] = 338;
            matrix_pos[43, 1] = 288;

            matrix_pos[44, 0] = 369;
            matrix_pos[44, 1] = 288;

            matrix_pos[45, 0] = 369;
            matrix_pos[45, 1] = 237;

            matrix_pos[46, 0] = 369;
            matrix_pos[46, 1] = 204;

            matrix_pos[47, 0] = 369;
            matrix_pos[47, 1] = 170;

            matrix_pos[48, 0] = 369;
            matrix_pos[48, 1] = 139;

            matrix_pos[49, 0] = 369;
            matrix_pos[49, 1] = 102;

            matrix_pos[50, 0] = 334;
            matrix_pos[50, 1] = 89;

            matrix_pos[51, 0] = 299;
            matrix_pos[51, 1] = 89;

            matrix_pos[52, 0] = 259;
            matrix_pos[52, 1] = 89;

            matrix_pos[53, 0] = 217;
            matrix_pos[53, 1] = 89;

            matrix_pos[54, 0] = 180;
            matrix_pos[54, 1] = 89;

            matrix_pos[55, 0] = 143;
            matrix_pos[55, 1] = 89;

            matrix_pos[56, 0] = 108;
            matrix_pos[56, 1] = 103;

            matrix_pos[57, 0] = 108;
            matrix_pos[57, 1] = 136;

            matrix_pos[58, 0] = 108;
            matrix_pos[58, 1] = 170;

            matrix_pos[59, 0] = 108;
            matrix_pos[59, 1] = 205;

            matrix_pos[60, 0] = 140;
            matrix_pos[60, 1] = 222;

            matrix_pos[61, 0] = 181;
            matrix_pos[61, 1] = 222;

            matrix_pos[62, 0] = 217;
            matrix_pos[62, 1] = 222;
        }


        public void Mueve(int dado)
        {
            casilla = casilla + dado;
            if (casilla==5)
            {

                casilla = 9 ;
            }
            else if (casilla == 9)
            {
                casilla = 14;
            }
            else if (casilla == 14)
            {
                casilla = 18;
            }
            else if (casilla == 18)
            {
                casilla = 23;
            }
            else if (casilla == 23)
            {
                casilla = 27;
            }
            else if (casilla == 27)
            {
                casilla = 32;
            }
            else if (casilla == 32)
            {
                casilla = 36;
            }
            else if (casilla == 36)
            {
                casilla = 41;
            }
            else if (casilla == 41)
            {
                casilla =45;
            }
            else if (casilla == 45)
            {
                casilla = 50;
            }
            else if (casilla == 50)
            {
                casilla = 54;
            }
            else if (casilla == 59)
            {
                casilla = 63;
            }
            //Puentes avanzo o retrocedo segun el caso
            else if (casilla == 6)
            {
                casilla = 12;
            }
            else if (casilla == 12)
            {
                casilla = 6;
            }
            //Laverinto
            else if (casilla == 42)
            {
                casilla = 30;
            }
            //Carcel
            else if (casilla == 52)
            {
                casilla = 52-3;
            }
            //Muerte por lo tanto retocedo al origen
            else if (casilla == 58)
            {
                casilla = 1;
            }
            //Condicion por las ultimas casilla
            else if (casilla == 60 && dado > 3 || casilla == 61 && dado > 2 || casilla == 62 && dado > 1)
            {
                casilla = casilla - dado;
            }
        }
        public void Set_casilla(int casilla)
        {
            this.casilla = casilla;
        }

        public int Get_casilla()
        {
            return this.casilla;
        }


        public int Get_x(int casilla)
        {
            return matrix_pos[casilla - 1, 0];
        }

        public int Get_y(int casilla)
        {
            return matrix_pos[casilla - 1, 1];
        }
    }
}
