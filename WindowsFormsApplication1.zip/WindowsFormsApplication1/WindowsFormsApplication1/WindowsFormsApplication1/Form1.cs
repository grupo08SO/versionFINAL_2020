﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading; 

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        Socket server;
        Thread atender;
        string miusuario;
        string idP;
        //mi id dentro de la partida
        int idJ;
        //id del jugador con turno;
        int idTurno;
        int totalJugadores;
        bool Partida=false;
        bool login = false;
        bool connected = false;

        posicion new_posicion_red = new posicion();
        posicion new_posicion_yellow = new posicion();
        posicion new_posicion_blue = new posicion();
        posicion new_posicion_black = new posicion();

        delegate void DelegateVarious(string frase, string tipo);
        delegate void DelegateMoverFicha(int loc_x, int loc_y, string tipo);

        // Inicializacion del datagrid de la lista de conectados
        private void initDataGrid()
        {
            Data.ColumnCount = 1;
            Data.Columns[0].Name = "JUGADORES ONLINE";
           
            invitados.ColumnCount = 1;
            invitados.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
        }

        public Form1()
        {
            InitializeComponent();
        }

        
        private void desconectar_Click_1(object sender, EventArgs e)
        {
            if(Partida==true)
            {
                var terminarSeguro = MessageBox.Show("Estas en mitad de la partida. Seguro que quieres desconectar?", "Game", MessageBoxButtons.YesNo);
                switch (terminarSeguro)
                {
                    case DialogResult.Yes:
                        // Enviamos al servidor el nombre tecleado
                        string mensaje = "90/" + miusuario + "/" + idP + "/" + idJ;
                        byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                        server.Send(msg);
                        break;
                    case DialogResult.No:
                        break;
                } 
            }
            else
            {
                string mensaje = "0/";
                // Enviamos al servidor el nombre tecleado
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);

                // Nos desconectamos
                server.Shutdown(SocketShutdown.Both);
                server.Close();
                atender.Abort();
                this.BackColor = Color.Black;
            } 
        }

        private void loging_Click(object sender, EventArgs e)
        {
            if(connected==true)
            {
                if(login==true)
                {
                    MessageBox.Show("Actualmente YA estas LOGGED IN");
                }
                else
                {
                    if ((usertxt.Text == "") || (passtxt.Text == ""))
                    {
                        MessageBox.Show("ERROR: El usuario o la contrasena estan vacias.");
                    }
                    else
                    {
                        // Creamos el mensaje para enviar al servidor
                        string mensaje = "1/" + usertxt.Text + "/" + passtxt.Text;
                        // Enviamos al servidor el nombre tecleado y la contrasena
                        byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                        server.Send(msg);
                    }
                }
             }
             else
             {
                MessageBox.Show("Primero debes conectarte con el servidor");
             }
        }

        private void signup_Click_1(object sender, EventArgs e)
        {
            if(login==true)
            {
                MessageBox.Show("Actualmente YA estas LOGGED IN");
            }
            else
            {
                if ((usertxt.Text == "") || (passtxt.Text == ""))
                {
                    MessageBox.Show("ERROR: El usuario o la contrasena estan vacias.");
                }
            else
                {
                    // Creamos el mensaje para enviar al servidor
                    string mensaje = "2/" + usertxt.Text + "/" + passtxt.Text;
                    // Enviamos al servidor el nombre tecleado y la contrasena
                    byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                    server.Send(msg);
                }
            }
        }


        private void consultas_Click_1(object sender, EventArgs e)
        {
           if (puntuacion.Checked)
                {
                    // Quiere saber los puntos
                    string mensaje = "3/" + nombrepuntuacion.Text;
                    // Enviamos al servidor el nombre tecleado
                    byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                    server.Send(msg);
                }
            if (veces.Checked)
                {
                    // Quiere saber el tiempo jugado
                    string mensaje = "4/" + nombreveces.Text;
                    // Enviamos al servidor el nombre tecleado
                    byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                    server.Send(msg);

                }
                if (ganador.Checked)
                {
                    // Quiere saber el tiempo jugado
                    string mensaje = "5/" + nombre1.Text + "/" + nombre2.Text + "/";
                    // Enviamos al servidor los nombres de los dos jugadores
                    byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                    server.Send(msg);

                }
                if (rankingprimero.Checked)
                {
                    // Quiere saber el tiempo jugado
                    string mensaje = "30/";
                    // Enviamos al servidor los nombres de los dos jugadores
                    byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                    server.Send(msg);
                }
                if (rankingultimo.Checked)
                {
                    // Quiere saber el tiempo jugado
                    string mensaje = "31/";
                    // Enviamos al servidor los nombres de los dos jugadores
                    byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                    server.Send(msg);
                }
             
        }

        private void conectar_Click(object sender, EventArgs e)
        {
            //Creamos un IPEndPoint con el ip y puerto del servidor al que queremos conectarnos
            if(iptxt.Text == "")
            {
                MessageBox.Show("ERROR: Introduce el IP, no puede estar vacio.");
            }
            else
            {

                IPAddress direc = IPAddress.Parse(iptxt.Text);
                IPEndPoint ipep = new IPEndPoint(direc, 50001);

                //Creamos el socket 
                server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                try
                {
                    //Intentamos conectar el socket
                    server.Connect(ipep);
                    //Si el servidor se conecta correctamente cambiamos el color de fondo de pantalla
                    this.BackColor = Color.LightSeaGreen;
                    //Informamos que se ha podido realizar la conexion
                    MessageBox.Show("Se ha podido conectar");
                    connected = true;
                 }

                catch (SocketException ex)
                {
                    //Si hay excepcion imprimimos error y salimos del programa con return 
                    MessageBox.Show("No he podido conectar con el servidor");
                    return;
                }

                //Inciamos el thread
                ThreadStart ts = delegate { AtenderServidor(); }; 
                atender = new Thread(ts); 
                atender.Start();
            }
        }

        //Funcion para atender el servidor
        private void AtenderServidor()
        {
            while (true)
            {
                byte[] msg2 = new byte[80];
                //Recibimos cualquier tipo de mensaje del servidor
                server.Receive(msg2); 
                //Quitamos informacion no deseada
                string mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0];
                //Procesamos el mensaje
                //El mensaje lo guardamos en un vector de dos posiciones
                string[] trozos = mensaje.Split('/');
                //La primera posicion del mensaje es el codigo
                int codigo = Convert.ToInt32(trozos[0]);
                //Creamos variable para guardar respuesta del servidor
                int respuesta;
                //Analizamos segun el codigo
                switch (codigo)
                {
                    //Log IN
                    case 1: 
                            respuesta = Convert.ToInt32(trozos[1]);
                            if (respuesta == 1)
                            {
                                MessageBox.Show("SUCCESS:Ha podido hacer log in");
                                login = true;
                                miusuario = usertxt.Text;
                            }
                            else
                            {
                                MessageBox.Show("ERROR: no ha sido posible hacer log in.");
                            }
                            break;
                    // SignUP
                    case 2:
                            respuesta = Convert.ToInt32(trozos[1]);
                            if (respuesta == 1)
                            {
                                MessageBox.Show("SUCCESS:Te has registrado correctamente.\n Ahora ya puedes hacer LOG IN");
                            }
                            else
                            {
                                MessageBox.Show("ERROR: El usuario ya existe\n Prueba con otros datos");
                            }
                            break;
                    //consulta Puntos totales
                    case 3: 
                            respuesta = Convert.ToInt32(trozos[1]);
                            if (respuesta >= 0)
                            {
                                MessageBox.Show("Sus puntos totales" + " son: " + respuesta.ToString());
                            }
                            else
                            {
                                MessageBox.Show("ERROR: no ha sido posible hacer la consulta");
                            }
                            break;
                    //Consulta el numero total de partidas que ha ganado un jugador
                    case 4:
                           respuesta = Convert.ToInt32(trozos[1]);
                           if (respuesta >= 0)
                           {
                               MessageBox.Show("Ha ganado en total:" + respuesta.ToString() + "partidas");
                           }
                           else
                           {
                               MessageBox.Show("ERROR: no ha sido posible hacer la consulta");
                           }
                           break;
                    //Consulta el jugador que esta en la posicion 1 del ranking
                    case 30:
                           string rankprimero = trozos[1];
                           if (rankprimero == "N0")
                           {
                               MessageBox.Show("ERROR: no ha sido posible hacer la consulta");
                           }
                           else
                           {
                               MessageBox.Show("El jugador que esta en la primera posicion del ranking es:" + rankprimero.ToString());
                           }
                           break;
                    //Consulta el jugador que esta en la posicion 1 del ranking
                    case 31:
                           string rankultimo = trozos[1];
                           if (rankultimo == "N0")
                           {
                               MessageBox.Show("ERROR: no ha sido posible hacer la consulta");
                           }
                           else
                           {
                               MessageBox.Show("El jugador que esta en la ultima posicion del ranking es:" + rankultimo.ToString());
                           }
                           break;
                    //Me informan del fin de la partida y me indican el ganador
                    case 22:
                           string ganadorPartida = trozos[1];
                           MessageBox.Show("Se ha terminado la partida y el ganador es:" + ganadorPartida);
                           Partida = false;
                           break;
                    //Me informan de la correcta actualizacion de la base de datos
                    case 23:
                           respuesta = Convert.ToInt32(trozos[1]);
                           if (respuesta == 1)
                           {
                               MessageBox.Show("Se ha actualizado la base de datos con los datos de esta partida");
                           }
                           else
                           {
                               MessageBox.Show("ERROR: no ha sido posible la actualizacion de la base de datos de esta partida");
                           }
                           break;
                    //Consulta cuantas veces ha ganado un jugador a otro
                    case 5: 
                           respuesta = Convert.ToInt32(trozos[1]);
                           if (respuesta >= 0)
                           {
                                MessageBox.Show("Le ha ganado" + " " + respuesta.ToString() + " " + "veces");
                           }
                           else
                           {
                                MessageBox.Show("ERROR: no ha sido posible hacer la consulta");
                           }
                           break;
                    //Notificacion para lista de conectados
                    case 6: 
                           string[] mssg;
                           mssg = trozos[1].Split(',');
                           Data.Invoke(new DelegateVarious(PonEnable), new object[] { "", "EliminaNombre" });
                           int rows = Convert.ToInt32(mssg[0]);
                           for (int i = 1; i<=rows; i++)
                           {
                             Data.Invoke(new DelegateVarious(PonEnable), new object[] { mssg[i], "EscribeNombre" });
                           }
                           break;
                    //Recibe una invitacion para jugar
                    case 8: 
                            string player = trozos[1];
                            idP = trozos[2].Split(',')[0];
                            var result = MessageBox.Show(player + " te ha invitado a jugar. Quieres ACCEPTAR?","Game",MessageBoxButtons.YesNo);
                            string respuestaInvitacion;
                            switch (result)
                            {   
                            case DialogResult.Yes:
                                respuestaInvitacion = "SI";
                                mensaje = "9/" + respuestaInvitacion + "/" + idP;
                                break;
                            case DialogResult.No:
                                respuestaInvitacion = "NO";
                                mensaje = "9/" + respuestaInvitacion + "/" + idP;
                                break;
                            }
                            // Enviamos al servidor
                            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                            server.Send(msg);
                            break;
                    //Recibela respuesta de la invitacion   
                    case 10:
                            idP = trozos[2];
                            if (trozos[1] == "SI") 
                            {
                                Partida = true;
                                idJ = Convert.ToInt32(trozos[3]);
                                totalJugadores = Convert.ToInt32(trozos[4]);
                                tablero.Invoke(new DelegateVarious(PonEnable), new object[] { "", "tablero" });
                                picdado.Invoke(new DelegateVarious(PonEnable), new object[] { "", "imagendado" });
                                BotonDado.Invoke(new DelegateVarious(PonEnable), new object[] { "", "dado" });
                                if (idJ == 0)
                                {
                                    BotonDado.Invoke(new DelegateVarious(PonEnable), new object[] { "", "HabilitarBotonDado" });
                                    turnoLBL.Invoke(new DelegateVarious(PonEnable), new object[] { "", "TuTurno" });
                                }
                                else
                                {
                                    turnoLBL.Invoke(new DelegateVarious(PonEnable), new object[] { "", "SuTurno" });
                                }
                                if(totalJugadores==2)
                                {
                                    rojo.Invoke(new DelegateVarious(PonEnable), new object[] { "", "rojo" });
                                    amarillo.Invoke(new DelegateVarious(PonEnable), new object[] { "", "amarillo" });
                                }
                                else if(totalJugadores==3)
                                {
                                    rojo.Invoke(new DelegateVarious(PonEnable), new object[] { "", "rojo" });
                                    amarillo.Invoke(new DelegateVarious(PonEnable), new object[] { "", "amarillo" });
                                    azul.Invoke(new DelegateVarious(PonEnable), new object[] { "", "azul" });
                                }
                                else if (totalJugadores==4)
                                {
                                    rojo.Invoke(new DelegateVarious(PonEnable), new object[] { "", "rojo" });
                                    amarillo.Invoke(new DelegateVarious(PonEnable), new object[] { "", "amarillo" });
                                    azul.Invoke(new DelegateVarious(PonEnable), new object[] { "", "azul" });
                                    negro.Invoke(new DelegateVarious(PonEnable), new object[] { "", "negro" });
                                }
                            }
                            else
                            {
                                MessageBox.Show("La partida no se jugara,ya que NO todos los jugadores \n  estan disponibles. \n");     
                            }
                            break;
                    //Recibe un mensaje del oponente
                    case 11:
                            string chat = trozos[1];
                            chatgrid.Invoke(new DelegateVarious(PonEnable), new object[] { "", "ChatGrid" });
                            chatgrid.Invoke(new DelegateVarious(PonEnable), new object[] { chat, "EscribeChat" });
                            break;
                    //Recibe resultado del dado 12/dado/idP/idJ
                    case 12:
                            int dado = Convert.ToInt32(trozos[1]);
                            idP = trozos[2];
                            idTurno = Convert.ToInt16(trozos[3]);
                            idJ = Convert.ToInt16(trozos[4]);
                            if(idTurno==idJ)
                            {
                                BotonDado.Invoke(new DelegateVarious(PonEnable), new object[] { "", "HabilitarBotonDado" });
                                turnoLBL.Invoke(new DelegateVarious(PonEnable), new object[] { "", "TuTurno" });
                            }
                            else
                            {
                                BotonDado.Invoke(new DelegateVarious(PonEnable), new object[] { "", "DesHabilitarBotonDado" });
                                turnoLBL.Invoke(new DelegateVarious(PonEnable), new object[] { "", "SuTurno" });
                            }
                            RecibirDado(dado,idTurno,idJ);
                            break;
                    //Respuesta a la peticion de eliminar la cuenta
                    case 20:
                            respuesta = Convert.ToInt32(trozos[1]);
                            if (respuesta == 1)
                            {
                                MessageBox.Show("ERROR:No se ha podido eliminar cuenta.\n Revisa los datos de usuario y contrasena");
                            }
                            else
                            {
                                MessageBox.Show("SUCCES: Tu cuenta ha sido eliminada\n");
                            }
                            break;
                    case 90:
                            Partida = false;
                            string jugadorDesconectado = trozos[1];
                            MessageBox.Show(jugadorDesconectado + " Ha abandonado la partida\n La partida queda anulada");
                            tablero.Invoke(new DelegateVarious(PonEnable), new object[] { "", "Destablero" });
                            picdado.Invoke(new DelegateVarious(PonEnable), new object[] { "", "Desimagendado" });
                            BotonDado.Invoke(new DelegateVarious(PonEnable), new object[] { "", "Desdado" });
                            break;
                    case 91:
                            Partida = false;
                            // Nos desconectamos
                            string message = "0/";
                            // Enviamos al servidor el nombre tecleado
                            byte[] msssg = System.Text.Encoding.ASCII.GetBytes(message);
                            server.Send(msssg);
                            server.Shutdown(SocketShutdown.Both);
                            server.Close();
                            atender.Abort();
                            break;
                            
                }
            }
        }


        //Funcion Solucionar Problema CrossThreading
        private void MoverFichas(int locX, int locY, string tipo)
        {
            if (tipo == "MoverRojo")
            {
                rojo.Location = new Point(locX, locY);
            }
            else if (tipo == "MoverAmarillo")
            {
                amarillo.Location = new Point(locX, locY);
            }
            else if (tipo == "MoverAzul")
            {
                azul.Location = new Point(locX, locY);
            }
            else if (tipo == "MoverNegro")
            {
                negro.Location = new Point(locX, locY);
            }
        }

        //Funcion PonEnable para solucionar el problema de Cross-Threading
        private void PonEnable(string frase, string tipo)
        {
            //Anadimos al jugador conectado en la lista
            if (tipo == "EscribeNombre") 
            {
                 Data.Rows.Add(frase);
            }
            //Escribimos los mensajes del chat
            if (tipo == "EscribeChat")
            {
                chatgrid.Rows.Add(frase);
            }
            if (tipo == "EscribeNombreInvitados")
            {
                invitados.Rows.Add(frase);
            }
            //Quitaos el jugador desconectado  de la lista
            else if (tipo == "EliminaNombre")
            {
                Data.Rows.Clear();
            }
            //Avisa al jugador de que es su turno
            else if (tipo == "TuTurno") turnoLBL.Text = "Es tu turno, tira el dado";
            //Avisa al jugador de que no su turno
            else if (tipo == "SuTurno") turnoLBL.Text = "No es tu turno,no puedes tirar el dado";
           //Escribimos el mensaje recibido por el chat en el label correspondiente
            else if (tipo == "ChatGrid")
            {
                chatgrid.Visible = true;
                label5.Visible = true;
            }
            else if (tipo == "tablero")
            {
                tablero.Visible = true;
            }
            else if (tipo == "dado")
            {
                BotonDado.Visible = true;
            }
            else if (tipo == "imagendado")
            {
                picdado.Visible = true;
            }
            else if (tipo == "Destablero")
            {
                tablero.Visible = false;
            }
            else if (tipo == "Desdado")
            {
                BotonDado.Visible = false;
            }
            else if (tipo == "Desimagendado")
            {
                picdado.Visible = false;
            }
            else if(tipo== "HabilitarBotonDado")
            {
                BotonDado.Enabled = true;
            }
            else if (tipo == "DesHabilitarBotonDado")
            {
                BotonDado.Enabled = false;
            }
            else if (tipo == "rojo")
            {
               rojo.Visible = true;
            }
            else if (tipo == "amarillo")
            {
                amarillo.Visible = true;
            }
            else if (tipo == "negro")
            {
                negro.Visible = true;
            }
            else if (tipo == "azul")
            {
                azul.Visible = true;
            }
        }

        //Definimos caracteristicas de la form al cargarse
        private void Form1_Load(object sender, EventArgs e)
        {
            initDataGrid();
            chatgrid.Visible = false;
            label5.Visible = false;
            tablero.Visible = false;
            picdado.Visible = false;
            BotonDado.Enabled = false;
            BotonDado.Visible = false;
            rojo.Visible = false;
            azul.Visible = false;
            amarillo.Visible = false;
            negro.Visible = false;
            passtxt.PasswordChar = '*';
        }

        //Funcion para definir el control del grid de la lista de conectados
        private void Data_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int i = e.RowIndex; //id de la fila qe click 
            string nameselected = Data.Rows[i].Cells[0].Value.ToString();
            if (nameselected != miusuario)
            {
                invitados.Invoke(new DelegateVarious(PonEnable), new object[] { nameselected, "EscribeNombreInvitados" });

            }
            else
            {
                MessageBox.Show("No puedes invitarte a tu mismo.\n Escoge otro jugador por favor.");
            }

        }

        //Funcion para definir el boton de invitar
        private void invitar_Click(object sender, EventArgs e)
        {
            string mensaje;
            string msm = "";
            string invitado = "";
            //Numero de jugadores totales invitados
            int numTotalInvitados = 0;
            if (invitados.RowCount < 2)
            {
                MessageBox.Show("No has elegido a nadie para jugar la partida");
            }
            else
            {
                int i = 0;
                while (i < invitados.RowCount - 1)
                {
                    //Guardamos el nombre de este jugador
                    invitado = invitados.Rows[i].Cells[0].Value.ToString();
                    //Preparamos los nombres de los invitados
                    msm = msm + "/" + invitado;
                    numTotalInvitados = numTotalInvitados + 1;
                    i++;
                }
            }
            if (numTotalInvitados == 0) return;
            //Creamos el mensaje para enviar al servidor
            mensaje = "7/" + Convert.ToString(numTotalInvitados) + msm;
            server.Send(System.Text.Encoding.ASCII.GetBytes(mensaje));
            label_participantes.Text += miusuario + ", ";

        }

        //Funcion para definir el boton de enviar un mensaje
        private void Chat_Click(object sender, EventArgs e)
        {
            string mensaje;
            //Creamos el mensaje para enviar al servidor
            mensaje = "11/" + miusuario + "/" + chattxt.Text + "/" + idP;
            //Enviamos el mensaje al servidor
            server.Send(System.Text.Encoding.ASCII.GetBytes(mensaje));
        }


        private void EnviarDado(int Dado)
        {
            string msm = "12/" + Dado.ToString() + "/" + idP.ToString() + "/" + idJ.ToString() + "/";
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(msm);
            server.Send(msg);
        }

        private void RecibirDado(int Dado,int idTurno,int idJ)
        {
            Cambiar_caraDado(Dado);
            MoverFicha(Dado,idTurno,idJ);
        }

        private void MoverFicha(int Dado, int idTurno,int idJ)
        {
            if(idTurno==0)
            {
                new_posicion_red.Mueve(Dado);
                int loc_x_red = new_posicion_red.Get_x(new_posicion_red.Get_casilla());
                int loc_y_red = new_posicion_red.Get_y(new_posicion_red.Get_casilla());

                if (new_posicion_black.Get_casilla() == new_posicion_red.Get_casilla() || new_posicion_red.Get_casilla() == new_posicion_yellow.Get_casilla() || new_posicion_red.Get_casilla() == new_posicion_blue.Get_casilla())
                {
                    rojo.Invoke(new DelegateMoverFicha(MoverFichas), new object[] { 137, 357, "MoverRojo" });
                }
                else
                {
                    rojo.Invoke(new DelegateMoverFicha(MoverFichas), new object[] { loc_x_red, loc_y_red, "MoverRojo" });
                }

                if (FinalPartida(loc_x_red, loc_y_red))
                {
                    EnviarFinalPartida(idJ, idTurno);
                }
            }
            if (idTurno == 1)
            {
                new_posicion_yellow.Mueve(Dado);
                int loc_x_yellow = new_posicion_yellow.Get_x(new_posicion_yellow.Get_casilla());
                int loc_y_yellow = new_posicion_yellow.Get_y(new_posicion_yellow.Get_casilla());
                if (new_posicion_yellow.Get_casilla() == new_posicion_red.Get_casilla() || new_posicion_black.Get_casilla() == new_posicion_yellow.Get_casilla() || new_posicion_yellow.Get_casilla() == new_posicion_blue.Get_casilla())
                {
                    amarillo.Invoke(new DelegateMoverFicha(MoverFichas), new object[] { 137, 357, "MoverAmarillo" });
                }
                else
                {
                    amarillo.Invoke(new DelegateMoverFicha(MoverFichas), new object[] { loc_x_yellow, loc_y_yellow, "MoverAmarillo" });
                }
                if (FinalPartida(loc_x_yellow, loc_y_yellow))
                {
                    EnviarFinalPartida(idJ, idTurno);
                }
            }
            if (idTurno == 2)
            {
                new_posicion_blue.Mueve(Dado);
                int loc_x_blue = new_posicion_blue.Get_x(new_posicion_blue.Get_casilla());
                int loc_y_blue = new_posicion_blue.Get_y(new_posicion_blue.Get_casilla());
                if (new_posicion_blue.Get_casilla() == new_posicion_red.Get_casilla() || new_posicion_blue.Get_casilla() == new_posicion_yellow.Get_casilla() || new_posicion_black.Get_casilla() == new_posicion_blue.Get_casilla())
                {
                    azul.Invoke(new DelegateMoverFicha(MoverFichas), new object[] { 137, 357, "MoverAzul" });
                }
                else
                {
                    azul.Invoke(new DelegateMoverFicha(MoverFichas), new object[] { loc_x_blue, loc_y_blue, "MoverAzul" });
                }
                if (FinalPartida(loc_x_blue, loc_y_blue))
                {
                    EnviarFinalPartida(idJ, idTurno);
                }
            }
            if (idTurno == 3)
            {
                new_posicion_black.Mueve(Dado);
                int loc_x_black = new_posicion_black.Get_x(new_posicion_black.Get_casilla());
                int loc_y_black = new_posicion_black.Get_y(new_posicion_black.Get_casilla());

                if (new_posicion_black.Get_casilla() == new_posicion_red.Get_casilla() || new_posicion_black.Get_casilla() == new_posicion_yellow.Get_casilla() || new_posicion_black.Get_casilla() == new_posicion_blue.Get_casilla())
                {
                    negro.Invoke(new DelegateMoverFicha(MoverFichas), new object[] { 137, 357, "MoverNegro" });
                }
                else
                {
                    negro.Invoke(new DelegateMoverFicha(MoverFichas), new object[] { loc_x_black, loc_y_black, "MoverNegro" });
                }
                if (FinalPartida(loc_x_black, loc_y_black))
                {
                    EnviarFinalPartida(idJ, idTurno);
                }
            }

            PasarTurno(idTurno);
        }

        



        private bool FinalPartida(int loc_x,int loc_y)
        {
            if(loc_x==217 && loc_y==222 )
                {
                    return true;
                }
            else 
                {
                    return false;
                }

        }

        private void EnviarFinalPartida(int idJ, int idTurno)
        {
            if (idJ==idTurno)
            {
                // Creamos el mensaje para enviar al servidor
                string mensaje = "22/" + miusuario + "/" + idP;
                // Enviamos al servidor el nombre tecleado y la contrasena
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
            }
        }


        private void PasarTurno(int idTurno)
        {
            if(totalJugadores==2)
            {
                if (idTurno == 0)
                {
                    idTurno = 1;
                }
                else 
                {
                    idTurno = 0;
                }

            }
            if (totalJugadores == 3)
            {
                if (idTurno == 0)
                {
                    idTurno = 1;
                }
                else if(idTurno == 1)
                {
                    idTurno = 2;
                }
                else if(idTurno == 2)
                {
                    idTurno = 0;
                }
            }
            if (totalJugadores == 4)
            {
                if (idTurno == 0)
                {
                    idTurno = 1;
                }
                else if (idTurno == 1)
                {
                    idTurno = 2;
                }
                else if (idTurno == 2)
                {
                    idTurno = 3;
                }
                else if (idTurno == 3)
                {
                    idTurno = 0;
                }
            }
            if(idTurno==idJ)
            {
                BotonDado.Invoke(new DelegateVarious(PonEnable), new object[] { "", "HabilitarBotonDado" });
                turnoLBL.Invoke(new DelegateVarious(PonEnable), new object[] { "", "TuTurno" });
            }
            else
            {
                BotonDado.Invoke(new DelegateVarious(PonEnable), new object[] { "", "DesHabilitarBotonDado" });
                turnoLBL.Invoke(new DelegateVarious(PonEnable), new object[] { "", "SuTurno" });
            }
        }

        private void OcupaCasilla(int loc_x, int loc_y,bool ocupa )
        {
            ocupa = true;
        }

        private void LiberaCasilla(int loc_x,int loc_, bool ocupa)
        {
            ocupa = false;
        }     

        private void Cambiar_caraDado(int dado)
        {
            if (dado == 1)
            {
                picdado.Image = Image.FromFile("cara1.png");
            }
            if (dado == 2)
            {
                picdado.Image = Image.FromFile("cara2.png");
            }
            if (dado == 3)
            {
                picdado.Image = Image.FromFile("cara3.png");
            }
            if (dado == 4)
            {
                picdado.Image = Image.FromFile("cara4.png");
            }
            if (dado == 5)
            {
                picdado.Image = Image.FromFile("cara5.png");
            }
            if (dado == 6)
            {
                picdado.Image = Image.FromFile("cara6.png");
            }
        }

        private void BotonDado_Click(object sender, EventArgs e)
        {
            Random dice = new Random();
            int dado = dice.Next(1, 7);
            EnviarDado(dado);
        }

        private void Delete_Click(object sender, EventArgs e)
        {

            if(login==false)
            {
                MessageBox.Show("No estas logged IN.\n Haz logIN para poder eliminarla");
            }
            else
            {
                if(Partida==true)
                {
                    MessageBox.Show("Estas jugando.\n Desconecta de la partida para poder eliminar cuenta ");
                }
                else
                {
                    // Creamos el mensaje para enviar al servidor
                    string mensaje = "20/" + usertxt.Text + "/" + passtxt.Text;
                    // Enviamos al servidor el nombre tecleado y la contrasena
                    byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                    server.Send(msg);
                }
            }
        }

        private void invitados_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void showpasword_CheckedChanged(object sender, EventArgs e)
        {
            if (showpasword.Checked == true)
            {
                passtxt.PasswordChar = '\0';
            }
            else
            {
                passtxt.PasswordChar = '*';
            }  
        }
    }
}
