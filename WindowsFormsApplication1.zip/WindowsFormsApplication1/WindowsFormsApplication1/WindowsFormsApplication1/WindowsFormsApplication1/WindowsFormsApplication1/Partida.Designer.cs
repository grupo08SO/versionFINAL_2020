﻿namespace WindowsFormsApplication1
{
    partial class Partida
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.tablero = new System.Windows.Forms.Panel();
            this.picdado = new System.Windows.Forms.PictureBox();
            this.dado = new System.Windows.Forms.Button();
            this.ficha = new System.Windows.Forms.PictureBox();
            this.tablero.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picdado)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ficha)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(559, 96);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // tablero
            // 
            this.tablero.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tablero.Controls.Add(this.ficha);
            this.tablero.Location = new System.Drawing.Point(12, 12);
            this.tablero.Name = "tablero";
            this.tablero.Size = new System.Drawing.Size(500, 400);
            this.tablero.TabIndex = 1;
            // 
            // picdado
            // 
            this.picdado.Location = new System.Drawing.Point(534, 19);
            this.picdado.Name = "picdado";
            this.picdado.Size = new System.Drawing.Size(100, 100);
            this.picdado.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picdado.TabIndex = 2;
            this.picdado.TabStop = false;
            // 
            // dado
            // 
            this.dado.Location = new System.Drawing.Point(547, 136);
            this.dado.Name = "dado";
            this.dado.Size = new System.Drawing.Size(75, 23);
            this.dado.TabIndex = 3;
            this.dado.Text = "Tirar";
            this.dado.UseVisualStyleBackColor = true;
            this.dado.Click += new System.EventHandler(this.dado_Click);
            // 
            // ficha
            // 
            this.ficha.Location = new System.Drawing.Point(0, 360);
            this.ficha.Name = "ficha";
            this.ficha.Size = new System.Drawing.Size(40, 40);
            this.ficha.TabIndex = 0;
            this.ficha.TabStop = false;
            // 
            // Partida
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(684, 419);
            this.Controls.Add(this.dado);
            this.Controls.Add(this.picdado);
            this.Controls.Add(this.tablero);
            this.Controls.Add(this.button1);
            this.Location = new System.Drawing.Point(200, 50);
            this.Name = "Partida";
            this.Text = "Partida";
            this.Load += new System.EventHandler(this.Partida_Load);
            this.tablero.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picdado)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ficha)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel tablero;
        private System.Windows.Forms.PictureBox picdado;
        private System.Windows.Forms.Button dado;
        private System.Windows.Forms.PictureBox ficha;
    }
}