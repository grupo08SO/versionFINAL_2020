﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsFormsApplication1
{
    class Board
    {
        int loc_x;
        int loc_y;

        public void Set_x(int loc_x)
        {
            this.loc_x = loc_x;
        }

        public void Set_y(int loc_y)
        {
            this.loc_y = loc_y;
        }

        public int Get_x()
        {
            return this.loc_x;
        }

        public int Get_y()
        {
            return this.loc_y;
        }

        public int Get_real_x(int x,int width)
        {
            double box_width = width / 10;
            double box_x = Math.Floor(x / box_width);
            int y_real = (Convert.ToInt32(box_x * box_width));
            return y_real;
        }

        public int Get_real_y(int y, int height)
        {
            double box_height = height/10;
            double box_y = Math.Floor(y/box_height);
            int y_real= (Convert.ToInt32((box_y*box_height)+1));
            return y_real; 
        }

        public int Get_box_y(int y, int height)
        {
            double box_height = height / 10;
            int box_y = Convert.ToInt32(Math.Floor(y / box_height));
            return box_y;
        }

        public int Get_box_x(int x, int width)
        {
            double box_width = width / 10;
            int box_x = Convert.ToInt32(Math.Floor(x / box_width));
            return box_x;
        }
    }
}
