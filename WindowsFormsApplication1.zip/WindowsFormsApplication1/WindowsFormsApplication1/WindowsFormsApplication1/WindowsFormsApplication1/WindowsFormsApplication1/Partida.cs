﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Partida : Form
    {
        Board panel = new Board();
        int boxes_y;
        int boxes_x;
        public Partida()
        {
            InitializeComponent();
        }

        private void Partida_Load(object sender, EventArgs e)
        {
            tablero.BackgroundImage = Image.FromFile("tableroca.jpg");
            picdado.Image = Image.FromFile("cara.png");
            ficha.Image = Image.FromFile("ficha.png");
        }


        private void MoverFicha(int pos_x, int pos_y,int dado)
        {
            int real_x = panel.Get_real_x(0, tablero.Size.Width);
            int real_y = panel.Get_real_y(360, tablero.Size.Height);

            PictureBox q = new PictureBox();
            q.Image = Image.FromFile("ficha.png");
            q.Size = new Size(40, 40);
            q.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            q.Location = new Point(real_x, real_y);
        }

        private void dado_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            int dice = rnd.Next(1, 7);
            int box_x = panel.Get_box_x(0, tablero.Size.Width);
            int box_y = panel.Get_box_y(360, tablero.Size.Height);
            if(dice == 1)
            {
                picdado.Image = Image.FromFile("cara1.png");
                MoverFicha(box_x,box_y ,dice);
            }
            if (dice == 2)
            {
                picdado.Image = Image.FromFile("cara2.png");
                MoverFicha(box_x,box_y ,dice);
            } 
            if (dice == 3)
            {
                picdado.Image = Image.FromFile("cara3.png");
                MoverFicha(box_x,box_y ,dice);
            }
            if (dice == 4)
            {
                picdado.Image = Image.FromFile("cara4.png");
                MoverFicha(box_x,box_y ,dice);
            }
            if (dice == 5)
            {
                picdado.Image = Image.FromFile("cara5.png");
                MoverFicha(box_x,box_y ,dice);
            }
            if (dice == 6)
            {
                picdado.Image = Image.FromFile("cara6.png");
                MoverFicha(box_x,box_y ,dice);
            }

        }
    }
}

