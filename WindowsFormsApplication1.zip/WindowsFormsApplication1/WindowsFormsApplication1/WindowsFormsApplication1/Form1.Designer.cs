﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.conectar = new System.Windows.Forms.Button();
            this.desconectar = new System.Windows.Forms.Button();
            this.iptxt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.usertxt = new System.Windows.Forms.TextBox();
            this.user = new System.Windows.Forms.Label();
            this.pass = new System.Windows.Forms.Label();
            this.passtxt = new System.Windows.Forms.TextBox();
            this.loging = new System.Windows.Forms.Button();
            this.signup = new System.Windows.Forms.Button();
            this.ganador = new System.Windows.Forms.RadioButton();
            this.puntuacion = new System.Windows.Forms.RadioButton();
            this.veces = new System.Windows.Forms.RadioButton();
            this.consultas = new System.Windows.Forms.Button();
            this.nombre1 = new System.Windows.Forms.TextBox();
            this.jugador1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.chattxt = new System.Windows.Forms.TextBox();
            this.nombre2 = new System.Windows.Forms.TextBox();
            this.nombrepuntuacion = new System.Windows.Forms.TextBox();
            this.nombreveces = new System.Windows.Forms.TextBox();
            this.Data = new System.Windows.Forms.DataGridView();
            this.invitar = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.Chat = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label_participantes = new System.Windows.Forms.Label();
            this.Label_partidaID = new System.Windows.Forms.Label();
            this.invitados = new System.Windows.Forms.DataGridView();
            this.BotonDado = new System.Windows.Forms.Button();
            this.turnoLBL = new System.Windows.Forms.Label();
            this.Delete = new System.Windows.Forms.Button();
            this.rankingprimero = new System.Windows.Forms.RadioButton();
            this.rankingultimo = new System.Windows.Forms.RadioButton();
            this.showpasword = new System.Windows.Forms.CheckBox();
            this.chatgrid = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.picdado = new System.Windows.Forms.PictureBox();
            this.tablero = new System.Windows.Forms.Panel();
            this.negro = new System.Windows.Forms.PictureBox();
            this.rojo = new System.Windows.Forms.PictureBox();
            this.amarillo = new System.Windows.Forms.PictureBox();
            this.azul = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.Data)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.invitados)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chatgrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picdado)).BeginInit();
            this.tablero.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.negro)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rojo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.amarillo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.azul)).BeginInit();
            this.SuspendLayout();
            // 
            // conectar
            // 
            this.conectar.BackColor = System.Drawing.Color.LightPink;
            this.conectar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.conectar.ForeColor = System.Drawing.Color.DimGray;
            this.conectar.Location = new System.Drawing.Point(1, 51);
            this.conectar.Name = "conectar";
            this.conectar.Size = new System.Drawing.Size(84, 31);
            this.conectar.TabIndex = 5;
            this.conectar.Text = "Conectar";
            this.conectar.UseVisualStyleBackColor = false;
            this.conectar.Click += new System.EventHandler(this.conectar_Click);
            // 
            // desconectar
            // 
            this.desconectar.BackColor = System.Drawing.Color.LightPink;
            this.desconectar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.desconectar.ForeColor = System.Drawing.Color.DimGray;
            this.desconectar.Location = new System.Drawing.Point(90, 52);
            this.desconectar.Margin = new System.Windows.Forms.Padding(2);
            this.desconectar.Name = "desconectar";
            this.desconectar.Size = new System.Drawing.Size(87, 30);
            this.desconectar.TabIndex = 8;
            this.desconectar.Text = "Desconectar";
            this.desconectar.UseVisualStyleBackColor = false;
            this.desconectar.Click += new System.EventHandler(this.desconectar_Click_1);
            // 
            // iptxt
            // 
            this.iptxt.Location = new System.Drawing.Point(23, 25);
            this.iptxt.Name = "iptxt";
            this.iptxt.Size = new System.Drawing.Size(86, 20);
            this.iptxt.TabIndex = 9;
            this.iptxt.Text = "147.83.117.22";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.label1.Location = new System.Drawing.Point(1, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(147, 15);
            this.label1.TabIndex = 10;
            this.label1.Text = "Introduce direccion IP";
            // 
            // usertxt
            // 
            this.usertxt.Location = new System.Drawing.Point(49, 118);
            this.usertxt.Name = "usertxt";
            this.usertxt.Size = new System.Drawing.Size(80, 20);
            this.usertxt.TabIndex = 11;
            // 
            // user
            // 
            this.user.AutoSize = true;
            this.user.Location = new System.Drawing.Point(12, 120);
            this.user.Name = "user";
            this.user.Size = new System.Drawing.Size(32, 13);
            this.user.TabIndex = 12;
            this.user.Text = "User:";
            // 
            // pass
            // 
            this.pass.AutoSize = true;
            this.pass.Location = new System.Drawing.Point(12, 149);
            this.pass.Name = "pass";
            this.pass.Size = new System.Drawing.Size(56, 13);
            this.pass.TabIndex = 13;
            this.pass.Text = "Password:";
            // 
            // passtxt
            // 
            this.passtxt.Location = new System.Drawing.Point(70, 147);
            this.passtxt.Name = "passtxt";
            this.passtxt.Size = new System.Drawing.Size(96, 20);
            this.passtxt.TabIndex = 14;
            // 
            // loging
            // 
            this.loging.BackColor = System.Drawing.Color.LightPink;
            this.loging.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loging.ForeColor = System.Drawing.Color.DimGray;
            this.loging.Location = new System.Drawing.Point(5, 205);
            this.loging.Name = "loging";
            this.loging.Size = new System.Drawing.Size(74, 23);
            this.loging.TabIndex = 15;
            this.loging.Text = "Log in";
            this.loging.UseVisualStyleBackColor = false;
            this.loging.Click += new System.EventHandler(this.loging_Click);
            // 
            // signup
            // 
            this.signup.BackColor = System.Drawing.Color.LightPink;
            this.signup.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.signup.ForeColor = System.Drawing.Color.DimGray;
            this.signup.Location = new System.Drawing.Point(84, 205);
            this.signup.Name = "signup";
            this.signup.Size = new System.Drawing.Size(74, 23);
            this.signup.TabIndex = 16;
            this.signup.Text = "Sign Up";
            this.signup.UseVisualStyleBackColor = false;
            this.signup.Click += new System.EventHandler(this.signup_Click_1);
            // 
            // ganador
            // 
            this.ganador.AutoSize = true;
            this.ganador.Checked = true;
            this.ganador.Location = new System.Drawing.Point(204, 28);
            this.ganador.Name = "ganador";
            this.ganador.Size = new System.Drawing.Size(272, 17);
            this.ganador.TabIndex = 17;
            this.ganador.TabStop = true;
            this.ganador.Text = "Cuantas veces ha ganado el jugador 1 al jugador 2?";
            this.ganador.UseVisualStyleBackColor = true;
            // 
            // puntuacion
            // 
            this.puntuacion.AutoSize = true;
            this.puntuacion.Location = new System.Drawing.Point(203, 91);
            this.puntuacion.Name = "puntuacion";
            this.puntuacion.Size = new System.Drawing.Size(157, 17);
            this.puntuacion.TabIndex = 18;
            this.puntuacion.Text = "Puntuacion total del jugador";
            this.puntuacion.UseVisualStyleBackColor = true;
            // 
            // veces
            // 
            this.veces.AutoSize = true;
            this.veces.Location = new System.Drawing.Point(204, 139);
            this.veces.Name = "veces";
            this.veces.Size = new System.Drawing.Size(228, 17);
            this.veces.TabIndex = 19;
            this.veces.Text = "Numero de partidas ganadas por el jugador";
            this.veces.UseVisualStyleBackColor = true;
            // 
            // consultas
            // 
            this.consultas.BackColor = System.Drawing.Color.LightPink;
            this.consultas.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.consultas.ForeColor = System.Drawing.Color.DimGray;
            this.consultas.Location = new System.Drawing.Point(291, 234);
            this.consultas.Name = "consultas";
            this.consultas.Size = new System.Drawing.Size(75, 23);
            this.consultas.TabIndex = 20;
            this.consultas.Text = "Enviar";
            this.consultas.UseVisualStyleBackColor = false;
            this.consultas.Click += new System.EventHandler(this.consultas_Click_1);
            // 
            // nombre1
            // 
            this.nombre1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nombre1.Location = new System.Drawing.Point(291, 47);
            this.nombre1.Name = "nombre1";
            this.nombre1.Size = new System.Drawing.Size(123, 20);
            this.nombre1.TabIndex = 21;
            // 
            // jugador1
            // 
            this.jugador1.AutoSize = true;
            this.jugador1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jugador1.Location = new System.Drawing.Point(226, 52);
            this.jugador1.Name = "jugador1";
            this.jugador1.Size = new System.Drawing.Size(59, 15);
            this.jugador1.TabIndex = 22;
            this.jugador1.Text = "Player 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(226, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 15);
            this.label2.TabIndex = 23;
            this.label2.Text = "Player 2";
            // 
            // chattxt
            // 
            this.chattxt.Location = new System.Drawing.Point(259, 458);
            this.chattxt.Name = "chattxt";
            this.chattxt.Size = new System.Drawing.Size(155, 20);
            this.chattxt.TabIndex = 24;
            // 
            // nombre2
            // 
            this.nombre2.Location = new System.Drawing.Point(290, 72);
            this.nombre2.Margin = new System.Windows.Forms.Padding(2);
            this.nombre2.Name = "nombre2";
            this.nombre2.Size = new System.Drawing.Size(123, 20);
            this.nombre2.TabIndex = 25;
            // 
            // nombrepuntuacion
            // 
            this.nombrepuntuacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nombrepuntuacion.Location = new System.Drawing.Point(291, 113);
            this.nombrepuntuacion.Name = "nombrepuntuacion";
            this.nombrepuntuacion.Size = new System.Drawing.Size(123, 20);
            this.nombrepuntuacion.TabIndex = 26;
            // 
            // nombreveces
            // 
            this.nombreveces.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nombreveces.Location = new System.Drawing.Point(291, 162);
            this.nombreveces.Name = "nombreveces";
            this.nombreveces.Size = new System.Drawing.Size(123, 20);
            this.nombreveces.TabIndex = 27;
            // 
            // Data
            // 
            this.Data.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Data.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Data.Location = new System.Drawing.Point(64, 278);
            this.Data.Name = "Data";
            this.Data.Size = new System.Drawing.Size(143, 93);
            this.Data.TabIndex = 28;
            this.Data.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Data_CellContentClick);
            // 
            // invitar
            // 
            this.invitar.BackColor = System.Drawing.Color.LightPink;
            this.invitar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.invitar.ForeColor = System.Drawing.Color.DimGray;
            this.invitar.Location = new System.Drawing.Point(173, 377);
            this.invitar.Name = "invitar";
            this.invitar.Size = new System.Drawing.Size(75, 23);
            this.invitar.TabIndex = 29;
            this.invitar.Text = "Invitar";
            this.invitar.UseVisualStyleBackColor = false;
            this.invitar.Click += new System.EventHandler(this.invitar_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Salmon;
            this.label3.Location = new System.Drawing.Point(274, 433);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(130, 15);
            this.label3.TabIndex = 30;
            this.label3.Text = "Escribe tu mensaje";
            // 
            // Chat
            // 
            this.Chat.BackColor = System.Drawing.Color.LightPink;
            this.Chat.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Chat.ForeColor = System.Drawing.Color.DimGray;
            this.Chat.Location = new System.Drawing.Point(291, 484);
            this.Chat.Name = "Chat";
            this.Chat.Size = new System.Drawing.Size(75, 23);
            this.Chat.TabIndex = 31;
            this.Chat.Text = "Enviar";
            this.Chat.UseVisualStyleBackColor = false;
            this.Chat.Click += new System.EventHandler(this.Chat_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Salmon;
            this.label5.Location = new System.Drawing.Point(81, 403);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 15);
            this.label5.TabIndex = 33;
            this.label5.Text = "CHAT";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.label4.Location = new System.Drawing.Point(1, 91);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(169, 15);
            this.label4.TabIndex = 34;
            this.label4.Text = "Inicia sesion o registrate!";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.label6.Location = new System.Drawing.Point(123, 403);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(194, 15);
            this.label6.TabIndex = 35;
            this.label6.Text = "Comunicate con tu oponente!";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.label7.Location = new System.Drawing.Point(216, 4);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(178, 20);
            this.label7.TabIndex = 36;
            this.label7.Text = "Consulta informacion";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.label8.Location = new System.Drawing.Point(100, 260);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(205, 15);
            this.label8.TabIndex = 37;
            this.label8.Text = "Invita a otro jugador conectado";
            // 
            // label_participantes
            // 
            this.label_participantes.AutoSize = true;
            this.label_participantes.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_participantes.ForeColor = System.Drawing.Color.Salmon;
            this.label_participantes.Location = new System.Drawing.Point(492, 462);
            this.label_participantes.Name = "label_participantes";
            this.label_participantes.Size = new System.Drawing.Size(0, 16);
            this.label_participantes.TabIndex = 39;
            // 
            // Label_partidaID
            // 
            this.Label_partidaID.AutoSize = true;
            this.Label_partidaID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_partidaID.ForeColor = System.Drawing.Color.Salmon;
            this.Label_partidaID.Location = new System.Drawing.Point(135, 462);
            this.Label_partidaID.Name = "Label_partidaID";
            this.Label_partidaID.Size = new System.Drawing.Size(0, 16);
            this.Label_partidaID.TabIndex = 41;
            // 
            // invitados
            // 
            this.invitados.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.invitados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.invitados.Location = new System.Drawing.Point(213, 278);
            this.invitados.Name = "invitados";
            this.invitados.Size = new System.Drawing.Size(147, 93);
            this.invitados.TabIndex = 42;
            this.invitados.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.invitados_CellContentClick);
            // 
            // BotonDado
            // 
            this.BotonDado.BackColor = System.Drawing.Color.LightPink;
            this.BotonDado.Location = new System.Drawing.Point(587, 495);
            this.BotonDado.Name = "BotonDado";
            this.BotonDado.Size = new System.Drawing.Size(75, 23);
            this.BotonDado.TabIndex = 44;
            this.BotonDado.Text = "Tirar";
            this.BotonDado.UseVisualStyleBackColor = false;
            this.BotonDado.Click += new System.EventHandler(this.BotonDado_Click);
            // 
            // turnoLBL
            // 
            this.turnoLBL.AutoSize = true;
            this.turnoLBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.turnoLBL.ForeColor = System.Drawing.Color.Salmon;
            this.turnoLBL.Location = new System.Drawing.Point(703, 498);
            this.turnoLBL.Name = "turnoLBL";
            this.turnoLBL.Size = new System.Drawing.Size(0, 16);
            this.turnoLBL.TabIndex = 46;
            // 
            // Delete
            // 
            this.Delete.BackColor = System.Drawing.Color.LightPink;
            this.Delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Delete.ForeColor = System.Drawing.Color.DimGray;
            this.Delete.Location = new System.Drawing.Point(26, 234);
            this.Delete.Name = "Delete";
            this.Delete.Size = new System.Drawing.Size(109, 23);
            this.Delete.TabIndex = 47;
            this.Delete.Text = "Eliminar cuenta";
            this.Delete.UseVisualStyleBackColor = false;
            this.Delete.Click += new System.EventHandler(this.Delete_Click);
            // 
            // rankingprimero
            // 
            this.rankingprimero.AutoSize = true;
            this.rankingprimero.Location = new System.Drawing.Point(204, 188);
            this.rankingprimero.Name = "rankingprimero";
            this.rankingprimero.Size = new System.Drawing.Size(239, 17);
            this.rankingprimero.TabIndex = 48;
            this.rankingprimero.Text = "Jugador que esta en la posicion 1 del ranking";
            this.rankingprimero.UseVisualStyleBackColor = true;
            // 
            // rankingultimo
            // 
            this.rankingultimo.AutoSize = true;
            this.rankingultimo.Location = new System.Drawing.Point(204, 211);
            this.rankingultimo.Name = "rankingultimo";
            this.rankingultimo.Size = new System.Drawing.Size(260, 17);
            this.rankingultimo.TabIndex = 49;
            this.rankingultimo.Text = "Jugador que esta en la ultima posicion del ranking";
            this.rankingultimo.UseVisualStyleBackColor = true;
            // 
            // showpasword
            // 
            this.showpasword.AutoSize = true;
            this.showpasword.Location = new System.Drawing.Point(23, 173);
            this.showpasword.Name = "showpasword";
            this.showpasword.Size = new System.Drawing.Size(117, 17);
            this.showpasword.TabIndex = 51;
            this.showpasword.Text = "Mostrar contrasena";
            this.showpasword.UseVisualStyleBackColor = true;
            this.showpasword.CheckedChanged += new System.EventHandler(this.showpasword_CheckedChanged);
            // 
            // chatgrid
            // 
            this.chatgrid.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.chatgrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.chatgrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1});
            this.chatgrid.Location = new System.Drawing.Point(5, 433);
            this.chatgrid.Name = "chatgrid";
            this.chatgrid.Size = new System.Drawing.Size(245, 93);
            this.chatgrid.TabIndex = 53;
            // 
            // Column1
            // 
            this.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column1.HeaderText = "Aqui esta disponible la conversacion";
            this.Column1.Name = "Column1";
            // 
            // picdado
            // 
            this.picdado.Image = global::WindowsFormsApplication1.Properties.Resources.cara;
            this.picdado.Location = new System.Drawing.Point(481, 418);
            this.picdado.Name = "picdado";
            this.picdado.Size = new System.Drawing.Size(100, 100);
            this.picdado.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picdado.TabIndex = 45;
            this.picdado.TabStop = false;
            // 
            // tablero
            // 
            this.tablero.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.tableroca;
            this.tablero.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tablero.Controls.Add(this.negro);
            this.tablero.Controls.Add(this.rojo);
            this.tablero.Controls.Add(this.amarillo);
            this.tablero.Controls.Add(this.azul);
            this.tablero.Location = new System.Drawing.Point(481, 12);
            this.tablero.Name = "tablero";
            this.tablero.Size = new System.Drawing.Size(500, 400);
            this.tablero.TabIndex = 43;
            // 
            // negro
            // 
            this.negro.BackColor = System.Drawing.Color.Transparent;
            this.negro.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.ficha;
            this.negro.ErrorImage = global::WindowsFormsApplication1.Properties.Resources.ficha;
            this.negro.Image = global::WindowsFormsApplication1.Properties.Resources.negro;
            this.negro.InitialImage = global::WindowsFormsApplication1.Properties.Resources.ficha;
            this.negro.Location = new System.Drawing.Point(23, 347);
            this.negro.Name = "negro";
            this.negro.Size = new System.Drawing.Size(36, 31);
            this.negro.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.negro.TabIndex = 4;
            this.negro.TabStop = false;
            // 
            // rojo
            // 
            this.rojo.BackColor = System.Drawing.Color.Transparent;
            this.rojo.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.rojoficha;
            this.rojo.ErrorImage = global::WindowsFormsApplication1.Properties.Resources.ficha;
            this.rojo.Image = global::WindowsFormsApplication1.Properties.Resources.rojoficha;
            this.rojo.InitialImage = global::WindowsFormsApplication1.Properties.Resources.ficha;
            this.rojo.Location = new System.Drawing.Point(138, 347);
            this.rojo.Name = "rojo";
            this.rojo.Size = new System.Drawing.Size(36, 31);
            this.rojo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.rojo.TabIndex = 3;
            this.rojo.TabStop = false;
            // 
            // amarillo
            // 
            this.amarillo.BackColor = System.Drawing.Color.Transparent;
            this.amarillo.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.ficha;
            this.amarillo.ErrorImage = global::WindowsFormsApplication1.Properties.Resources.ficha;
            this.amarillo.Image = global::WindowsFormsApplication1.Properties.Resources.verdeficha;
            this.amarillo.InitialImage = global::WindowsFormsApplication1.Properties.Resources.ficha;
            this.amarillo.Location = new System.Drawing.Point(96, 347);
            this.amarillo.Name = "amarillo";
            this.amarillo.Size = new System.Drawing.Size(36, 31);
            this.amarillo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.amarillo.TabIndex = 2;
            this.amarillo.TabStop = false;
            // 
            // azul
            // 
            this.azul.BackColor = System.Drawing.Color.Transparent;
            this.azul.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.ficha;
            this.azul.ErrorImage = global::WindowsFormsApplication1.Properties.Resources.ficha;
            this.azul.Image = global::WindowsFormsApplication1.Properties.Resources.blueficha;
            this.azul.InitialImage = global::WindowsFormsApplication1.Properties.Resources.ficha;
            this.azul.Location = new System.Drawing.Point(56, 347);
            this.azul.Name = "azul";
            this.azul.Size = new System.Drawing.Size(36, 31);
            this.azul.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.azul.TabIndex = 1;
            this.azul.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(991, 530);
            this.Controls.Add(this.chatgrid);
            this.Controls.Add(this.showpasword);
            this.Controls.Add(this.rankingultimo);
            this.Controls.Add(this.rankingprimero);
            this.Controls.Add(this.Delete);
            this.Controls.Add(this.turnoLBL);
            this.Controls.Add(this.picdado);
            this.Controls.Add(this.BotonDado);
            this.Controls.Add(this.tablero);
            this.Controls.Add(this.invitados);
            this.Controls.Add(this.Label_partidaID);
            this.Controls.Add(this.label_participantes);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Chat);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.invitar);
            this.Controls.Add(this.Data);
            this.Controls.Add(this.nombreveces);
            this.Controls.Add(this.nombrepuntuacion);
            this.Controls.Add(this.nombre2);
            this.Controls.Add(this.chattxt);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.jugador1);
            this.Controls.Add(this.nombre1);
            this.Controls.Add(this.consultas);
            this.Controls.Add(this.veces);
            this.Controls.Add(this.puntuacion);
            this.Controls.Add(this.ganador);
            this.Controls.Add(this.signup);
            this.Controls.Add(this.loging);
            this.Controls.Add(this.passtxt);
            this.Controls.Add(this.pass);
            this.Controls.Add(this.user);
            this.Controls.Add(this.usertxt);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.iptxt);
            this.Controls.Add(this.desconectar);
            this.Controls.Add(this.conectar);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Data)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.invitados)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chatgrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picdado)).EndInit();
            this.tablero.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.negro)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rojo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.amarillo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.azul)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button conectar;
        private System.Windows.Forms.Button desconectar;
        private System.Windows.Forms.TextBox iptxt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox usertxt;
        private System.Windows.Forms.Label user;
        private System.Windows.Forms.Label pass;
        private System.Windows.Forms.TextBox passtxt;
        private System.Windows.Forms.Button loging;
        private System.Windows.Forms.Button signup;
        private System.Windows.Forms.RadioButton ganador;
        private System.Windows.Forms.RadioButton puntuacion;
        private System.Windows.Forms.RadioButton veces;
        private System.Windows.Forms.Button consultas;
        private System.Windows.Forms.TextBox nombre1;
        private System.Windows.Forms.Label jugador1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox chattxt;
        private System.Windows.Forms.TextBox nombre2;
        private System.Windows.Forms.TextBox nombrepuntuacion;
        private System.Windows.Forms.TextBox nombreveces;
        private System.Windows.Forms.DataGridView Data;
        private System.Windows.Forms.Button invitar;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button Chat;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label_participantes;
        private System.Windows.Forms.Label Label_partidaID;
        private System.Windows.Forms.DataGridView invitados;
        private System.Windows.Forms.Panel tablero;
        private System.Windows.Forms.Button BotonDado;
        private System.Windows.Forms.PictureBox picdado;
        private System.Windows.Forms.PictureBox azul;
        private System.Windows.Forms.PictureBox amarillo;
        private System.Windows.Forms.PictureBox rojo;
        private System.Windows.Forms.PictureBox negro;
        private System.Windows.Forms.Label turnoLBL;
        private System.Windows.Forms.Button Delete;
        private System.Windows.Forms.RadioButton rankingprimero;
        private System.Windows.Forms.RadioButton rankingultimo;
        private System.Windows.Forms.CheckBox showpasword;
        private System.Windows.Forms.DataGridView chatgrid;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
    }
}

